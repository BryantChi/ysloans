<!-- Marquee Text Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('marquee_text', 'Marquee Text:'); ?>

    <?php echo Form::text('marquee_text', null, ['class' => 'form-control']); ?>

</div>

<!-- Used Field -->

<div class="form-group col-sm-6">
    <label for="toggle-button">啟用/停用</label>
    <div class="custom-control custom-switch">
        <?php echo Form::checkbox('used', 1, $marqueeInfo->used ?? true, ['class' => 'custom-control-input', 'id' => 'toggle-button']); ?>

        <label class="custom-control-label" for="toggle-button"></label>
    </div>
</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/ysloans/resources/views/admin/marquee_infos/fields.blade.php ENDPATH**/ ?>