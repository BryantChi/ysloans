<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    
    <input type="text" name="name" id="name" value="<?php echo e($adminUsers->name ?? ''); ?>" class="form-control" required <?php echo e(Request::is('admin/adminUsers/edit*') ? 'disabled' : ''); ?>>
</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    
    <input type="text" name="email" id="email" value="<?php echo e($adminUsers->email ?? ''); ?>" class="form-control" required <?php echo e(Request::is('admin/adminUsers/edit*') ? 'disabled' : ''); ?>>
</div>

<!-- Password Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('password', 'Password:'); ?>

    
    <input type="password" name="password" id="password" class="form-control" placeholder="請輸入密碼，最少6碼" minlength="6">
    <?php if(Request::is('admin/adminUsers/edit*')): ?>
    <span class="help-block text-danger">★若欲變更密碼，才需輸入密碼，最少6碼</span>
    <?php endif; ?>
</div>

<div class="form-group col-sm-6">
    <?php echo Form::label('password_confirmation', 'Password Confirmation:'); ?>

    <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" placeholder="請輸入密碼，最少6碼" minlength="6">
    <?php if(Request::is('admin/adminUsers/edit*')): ?>
    <span class="help-block text-danger">★若欲變更密碼，才需輸入密碼，最少6碼</span>
    <?php endif; ?>
</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/ysloans/resources/views/admin/admin_users/fields.blade.php ENDPATH**/ ?>