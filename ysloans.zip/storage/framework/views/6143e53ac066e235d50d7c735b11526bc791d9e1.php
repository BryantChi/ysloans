<!-- Carousel Start -->
<div class="site-blocks-cover overlay" data-aos="fade" data-stellar-background-ratio="0.5">
    <div id="hero" class="site-blocks-cover2 overlay2">
        <div class="swiper heroSwiper">
            <div class="swiper-wrapper">
                <div class="swiper-slide item1">
                </div>
                <div class="swiper-slide item2">
                </div>
                <div class="swiper-slide item3">
                </div>
            </div>
            <!-- <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div> -->
        </div>
    </div>
</div>
<!-- Carousel End -->

<!-- Marquee Start -->
<div class="container-fluid p-0 m-0 bg-white shadow position-relative" style="z-index: 2;">
    <!-- box-shadow: 1px 1px 5px 1px rgba(0, 0, 0, 0.2); -->
    <div class="container">
        <div class="row py-42 px-md-4 px-3 mx-lg-auto mx-2">
            <div class="marquee" data-aos="zoom-in" data-aos-delay="200">
                <div class="marquee-text">
                    <?php echo e($marqueeText); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Marquee End -->
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/ysloans/resources/views/layouts_main/hero.blade.php ENDPATH**/ ?>