<div class="table-responsive">
    <table class="table" id="newsInfos-table">
        <thead>
            <tr>
                <th>標題</th>
                <th>封面</th>
                <th>狀態</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $newsInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newsInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($newsInfo->title); ?></td>
                    <td>
                        <img src="<?php echo e(env('APP_URL', 'https://ysloans.tw') . '/uploads/' . $newsInfo->cover_front_image); ?>" class="img-fluid" width="100" alt="">
                    </td>
                    <td><?php echo e($newsInfo->status == 1 ? '啟用' : '停用'); ?></td>
                    <td width="120">
                        <?php echo Form::open(['route' => ['admin.newsInfos.destroy', $newsInfo->id], 'method' => 'delete']); ?>

                        <div class='btn-group'>
                            
                            <a href="<?php echo e(route('admin.newsInfos.edit', [$newsInfo->id])); ?>"
                                class='btn btn-default btn-xs'>
                                <i class="far fa-edit"></i>
                            </a>
                            <?php echo Form::button('<i class="far fa-trash-alt"></i>', [
                                'type' => 'submit',
                                'class' => 'btn btn-danger btn-xs',
                                'onclick' => "return check(this);",
                            ]); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/ysloans/resources/views/admin/news_infos/table.blade.php ENDPATH**/ ?>