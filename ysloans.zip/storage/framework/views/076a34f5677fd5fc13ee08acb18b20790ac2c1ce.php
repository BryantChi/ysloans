<div class="table-responsive">
    <table class="table" id="marqueeInfos-table">
        <thead>
            <tr>
                <th>跑馬燈文字</th>
                <th>狀態</th>
                <th colspan="3">操作</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $marqueeInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marqueeInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="min-width: 300px;"><?php echo e($marqueeInfo->marquee_text); ?></td>
                    <td width="120"><?php echo e($marqueeInfo->used == 1 ? '啟用' : '停用'); ?></td>
                    <td width="120">
                        <?php echo Form::open(['route' => ['admin.marqueeInfos.destroy', $marqueeInfo->id], 'method' => 'delete']); ?>

                        <div class='btn-group'>
                            
                            <a href="<?php echo e(route('admin.marqueeInfos.edit', [$marqueeInfo->id])); ?>"
                                class='btn btn-default btn-sm'>
                                <i class="far fa-edit"></i>
                            </a>
                            <?php echo Form::button('<i class="far fa-trash-alt"></i>', [
                                'type' => 'button',
                                'class' => 'btn btn-danger btn-sm',
                                'onclick' => "return check(this)",
                            ]); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/ysloans/resources/views/admin/marquee_infos/table.blade.php ENDPATH**/ ?>